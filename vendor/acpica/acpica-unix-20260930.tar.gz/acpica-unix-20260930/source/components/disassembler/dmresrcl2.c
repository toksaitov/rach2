/*******************************************************************************
 *
 * Module Name: dmresrcl2.c - "Large" Resource Descriptor disassembly (#2)
 *
 ******************************************************************************/

/******************************************************************************
 *
 * Copyright (c) 1999 - 2026, Intel Corp.
 * SPDX-License-Identifier: BSD-3-Clause OR GPL-2.0-only
 *
 *****************************************************************************/

#include "acpi.h"
#include "accommon.h"
#include "acdisasm.h"


#define _COMPONENT          ACPI_CA_DEBUGGER
        ACPI_MODULE_NAME    ("dbresrcl2")

/* Local prototypes */

static void
AcpiDmCsi2SerialBusDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level);

static void
AcpiDmI2cSerialBusDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level);

static void
AcpiDmSpiSerialBusDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level);

static void
AcpiDmUartSerialBusDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level);

static void
AcpiDmGpioCommon (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Level);

static void
AcpiDmDumpRawDataBuffer (
    UINT8                   *Buffer,
    UINT32                  Length,
    UINT32                  Level);


/* Dispatch table for the serial bus descriptors */

static ACPI_RESOURCE_HANDLER        SerialBusResourceDispatch [] =
{
    NULL,
    AcpiDmI2cSerialBusDescriptor,
    AcpiDmSpiSerialBusDescriptor,
    AcpiDmUartSerialBusDescriptor,
    AcpiDmCsi2SerialBusDescriptor
};


/*******************************************************************************
 *
 * FUNCTION:    AcpiDmDumpRawDataBuffer
 *
 * PARAMETERS:  Buffer              - Pointer to the data bytes
 *              Length              - Length of the descriptor in bytes
 *              Level               - Current source code indentation level
 *
 * RETURN:      None
 *
 * DESCRIPTION: Dump a data buffer as a RawDataBuffer() object. Used for
 *              vendor data bytes.
 *
 ******************************************************************************/

static void
AcpiDmDumpRawDataBuffer (
    UINT8                   *Buffer,
    UINT32                  Length,
    UINT32                  Level)
{
    UINT32                  Index;
    UINT32                  i;
    UINT32                  j;


    if (!Length)
    {
        return;
    }

    AcpiOsPrintf ("RawDataBuffer (0x%.2X)  // Vendor Data", Length);

    AcpiOsPrintf ("\n");
    AcpiDmIndent (Level + 1);
    AcpiOsPrintf ("{\n");
    AcpiDmIndent (Level + 2);

    for (i = 0; i < Length;)
    {
        for (j = 0; j < 8; j++)
        {
            Index = i + j;
            if (Index >= Length)
            {
                goto Finish;
            }

            AcpiOsPrintf ("0x%2.2X", Buffer[Index]);
            if ((Index + 1) >= Length)
            {
                goto Finish;
            }

            AcpiOsPrintf (", ");
        }

        AcpiOsPrintf ("\n");
        AcpiDmIndent (Level + 2);

        i += 8;
    }

Finish:
    AcpiOsPrintf ("\n");
    AcpiDmIndent (Level + 1);
    AcpiOsPrintf ("}");
}


/*******************************************************************************
 *
 * FUNCTION:    AcpiDmGpioCommon
 *
 * PARAMETERS:  Info                - Extra resource info
 *              Resource            - Pointer to the resource descriptor
 *              Level               - Current source code indentation level
 *
 * RETURN:      None
 *
 * DESCRIPTION: Decode common parts of a GPIO Interrupt descriptor
 *
 ******************************************************************************/

static void
AcpiDmGpioCommon (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Level)
{
    UINT16                  *PinList;
    UINT8                   *VendorData;
    char                    *DeviceName = NULL;
    UINT32                  PinCount;
    UINT32                  i;


    /* ResourceSource, ResourceSourceIndex, ResourceType */

    AcpiDmIndent (Level + 1);
    if (Resource->Gpio.ResSourceOffset)
    {
        DeviceName = ACPI_ADD_PTR (char,
            Resource, Resource->Gpio.ResSourceOffset),
        AcpiUtPrintString (DeviceName, ACPI_UINT16_MAX);
    }

    AcpiOsPrintf (", ");
    AcpiOsPrintf ("0x%2.2X, ", Resource->Gpio.ResSourceIndex);
    AcpiOsPrintf ("%s, ",
        AcpiGbl_ConsumeDecode [ACPI_GET_1BIT_FLAG (Resource->Gpio.Flags)]);

    /* Insert a descriptor name */

    AcpiDmDescriptorName ();
    AcpiOsPrintf (",");

    /* Dump the vendor data */

    if (Resource->Gpio.VendorOffset)
    {
        AcpiOsPrintf ("\n");
        AcpiDmIndent (Level + 1);
        VendorData = ACPI_ADD_PTR (UINT8, Resource,
            Resource->Gpio.VendorOffset);

        AcpiDmDumpRawDataBuffer (VendorData,
            Resource->Gpio.VendorLength, Level);
    }

    AcpiOsPrintf (")\n");

    /* Dump the interrupt list */

    AcpiDmIndent (Level + 1);
    AcpiOsPrintf ("{   // Pin list\n");

    PinCount = ((UINT32) (Resource->Gpio.ResSourceOffset -
        Resource->Gpio.PinTableOffset)) /
        sizeof (UINT16);

    PinList = (UINT16 *) ACPI_ADD_PTR (char, Resource,
        Resource->Gpio.PinTableOffset);

    for (i = 0; i < PinCount; i++)
    {
        AcpiDmIndent (Level + 2);
        AcpiOsPrintf ("0x%4.4X%s\n", PinList[i],
            ((i + 1) < PinCount) ? "," : "");
    }

    AcpiDmIndent (Level + 1);
    AcpiOsPrintf ("}\n");

    MpSaveGpioInfo (Info->MappingOp, Resource,
        PinCount, PinList, DeviceName);
}


/*******************************************************************************
 *
 * FUNCTION:    AcpiDmGpioIntDescriptor
 *
 * PARAMETERS:  Info                - Extra resource info
 *              Resource            - Pointer to the resource descriptor
 *              Length              - Length of the descriptor in bytes
 *              Level               - Current source code indentation level
 *
 * RETURN:      None
 *
 * DESCRIPTION: Decode a GPIO Interrupt descriptor
 *
 ******************************************************************************/

static void
AcpiDmGpioIntDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level)
{

    /* Dump the GpioInt-specific portion of the descriptor */

    /* EdgeLevel, ActiveLevel, Shared */

    AcpiDmIndent (Level);
    AcpiOsPrintf ("GpioInt (%s, %s, %s, ",
        AcpiGbl_HeDecode [ACPI_GET_1BIT_FLAG (Resource->Gpio.IntFlags)],
        AcpiGbl_LlDecode [ACPI_EXTRACT_2BIT_FLAG (Resource->Gpio.IntFlags, 1)],
        AcpiGbl_ShrDecode [ACPI_EXTRACT_2BIT_FLAG (Resource->Gpio.IntFlags, 3)]);

    /* PinConfig, DebounceTimeout */

    if (Resource->Gpio.PinConfig <= 3)
    {
        AcpiOsPrintf ("%s, ",
            AcpiGbl_PpcDecode[Resource->Gpio.PinConfig]);
    }
    else
    {
        AcpiOsPrintf ("0x%2.2X, ", Resource->Gpio.PinConfig);
    }
    AcpiOsPrintf ("0x%4.4X,\n", Resource->Gpio.DebounceTimeout);

    /* Dump the GpioInt/GpioIo common portion of the descriptor */

    AcpiDmGpioCommon (Info, Resource, Level);
}


/*******************************************************************************
 *
 * FUNCTION:    AcpiDmGpioIoDescriptor
 *
 * PARAMETERS:  Info                - Extra resource info
 *              Resource            - Pointer to the resource descriptor
 *              Length              - Length of the descriptor in bytes
 *              Level               - Current source code indentation level
 *
 * RETURN:      None
 *
 * DESCRIPTION: Decode a GPIO I/O descriptor
 *
 ******************************************************************************/

static void
AcpiDmGpioIoDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level)
{

    /* Dump the GpioIo-specific portion of the descriptor */

    /* Shared, PinConfig */

    AcpiDmIndent (Level);
    AcpiOsPrintf ("GpioIo (%s, ",
        AcpiGbl_ShrDecode [ACPI_EXTRACT_2BIT_FLAG (Resource->Gpio.IntFlags, 3)]);

    if (Resource->Gpio.PinConfig <= 3)
    {
        AcpiOsPrintf ("%s, ",
            AcpiGbl_PpcDecode[Resource->Gpio.PinConfig]);
    }
    else
    {
        AcpiOsPrintf ("0x%2.2X, ", Resource->Gpio.PinConfig);
    }

    /* DebounceTimeout, DriveStrength, IoRestriction */

    AcpiOsPrintf ("0x%4.4X, ", Resource->Gpio.DebounceTimeout);
    AcpiOsPrintf ("0x%4.4X, ", Resource->Gpio.DriveStrength);
    AcpiOsPrintf ("%s,\n",
        AcpiGbl_IorDecode [ACPI_GET_2BIT_FLAG (Resource->Gpio.IntFlags)]);

    /* Dump the GpioInt/GpioIo common portion of the descriptor */

    AcpiDmGpioCommon (Info, Resource, Level);
}


/*******************************************************************************
 *
 * FUNCTION:    AcpiDmGpioDescriptor
 *
 * PARAMETERS:  Info                - Extra resource info
 *              Resource            - Pointer to the resource descriptor
 *              Length              - Length of the descriptor in bytes
 *              Level               - Current source code indentation level
 *
 * RETURN:      None
 *
 * DESCRIPTION: Decode a GpioInt/GpioIo GPIO Interrupt/IO descriptor
 *
 ******************************************************************************/

void
AcpiDmGpioDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level)
{
    UINT8                   ConnectionType;


    ConnectionType = Resource->Gpio.ConnectionType;

    switch (ConnectionType)
    {
    case AML_RESOURCE_GPIO_TYPE_INT:

        AcpiDmGpioIntDescriptor (Info, Resource, Length, Level);
        break;

    case AML_RESOURCE_GPIO_TYPE_IO:

        AcpiDmGpioIoDescriptor (Info, Resource, Length, Level);
        break;

    default:

        AcpiOsPrintf ("Unknown GPIO type\n");
        break;
    }
}

void
AcpiDmClockInputDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level)
{
    char                    *DeviceName = NULL;
    UINT8                   *ResourceIndex = NULL;
    AcpiDmIndent (Level);

    AcpiOsPrintf ("ClockInput (");

    AcpiOsPrintf ("0x%8.8X, ", Resource->ClockInput.FrequencyNumerator);

    AcpiOsPrintf ("0x%4.4X, ", Resource->ClockInput.FrequencyDivisor);

    AcpiOsPrintf ("%s, ",
        AcpiGbl_ClockInputScale [ACPI_EXTRACT_2BIT_FLAG (Resource->ClockInput.Flags, 1)]);

    AcpiOsPrintf ("%s, ",
        AcpiGbl_ClockInputMode [ACPI_GET_1BIT_FLAG (Resource->ClockInput.Flags)]);

    if (Length > sizeof(Resource->ClockInput))
    {
        DeviceName = ACPI_ADD_PTR (char,
            Resource, sizeof(Resource->ClockInput)+1),
        AcpiUtPrintString (DeviceName, ACPI_UINT16_MAX);

        AcpiOsPrintf (", ");
        ResourceIndex = ACPI_ADD_PTR (UINT8,
            Resource, sizeof(Resource->ClockInput)),

        AcpiOsPrintf ("0x%2.2X", *ResourceIndex);
    }

    AcpiOsPrintf (")\n");

}

/*******************************************************************************
 *
 * FUNCTION:    AcpiDmPinFunctionDescriptor
 *
 * PARAMETERS:  Info                - Extra resource info
 *              Resource            - Pointer to the resource descriptor
 *              Length              - Length of the descriptor in bytes
 *              Level               - Current source code indentation level
 *
 * RETURN:      None
 *
 * DESCRIPTION: Decode a PinFunction descriptor
 *
 ******************************************************************************/

void
AcpiDmPinFunctionDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level)
{
    UINT16                  *PinList;
    UINT8                   *VendorData;
    char                    *DeviceName = NULL;
    UINT32                  PinCount;
    UINT32                  i;

    AcpiDmIndent (Level);
    AcpiOsPrintf ("PinFunction (%s, ",
        AcpiGbl_ShrDecode [ACPI_GET_1BIT_FLAG (Resource->PinFunction.Flags)]);

    if (Resource->PinFunction.PinConfig <= 3)
    {
        AcpiOsPrintf ("%s, ",
            AcpiGbl_PpcDecode[Resource->PinFunction.PinConfig]);
    }
    else
    {
        AcpiOsPrintf ("0x%2.2X, ", Resource->PinFunction.PinConfig);
    }

    /* FunctionNumber */

    AcpiOsPrintf ("0x%4.4X, ", Resource->PinFunction.FunctionNumber);

    if (Resource->PinFunction.ResSourceOffset)
    {
        DeviceName = ACPI_ADD_PTR (char,
            Resource, Resource->PinFunction.ResSourceOffset),
        AcpiUtPrintString (DeviceName, ACPI_UINT16_MAX);
    }

    AcpiOsPrintf (", ");
    AcpiOsPrintf ("0x%2.2X,\n", Resource->PinFunction.ResSourceIndex);

    AcpiDmIndent (Level + 1);

    /* Always ResourceConsumer */
    AcpiOsPrintf ("%s, ", AcpiGbl_ConsumeDecode [ACPI_CONSUMER]);

    /* Insert a descriptor name */

    AcpiDmDescriptorName ();

    AcpiOsPrintf (",");

    /* Dump the vendor data */

    if (Resource->PinFunction.VendorLength)
    {
        AcpiOsPrintf ("\n");
        AcpiDmIndent (Level + 1);
        VendorData = ACPI_ADD_PTR (UINT8, Resource,
            Resource->PinFunction.VendorOffset);

        AcpiDmDumpRawDataBuffer (VendorData,
            Resource->PinFunction.VendorLength, Level);
    }

    AcpiOsPrintf (")\n");

    AcpiDmIndent (Level + 1);

    /* Dump the interrupt list */

    AcpiOsPrintf ("{   // Pin list\n");

    PinCount = ((UINT32) (Resource->PinFunction.ResSourceOffset -
        Resource->PinFunction.PinTableOffset)) /
        sizeof (UINT16);

    PinList = (UINT16 *) ACPI_ADD_PTR (char, Resource,
        Resource->PinFunction.PinTableOffset);

    for (i = 0; i < PinCount; i++)
    {
        AcpiDmIndent (Level + 2);
        AcpiOsPrintf ("0x%4.4X%s\n", PinList[i],
            ((i + 1) < PinCount) ? "," : "");
    }

    AcpiDmIndent (Level + 1);
    AcpiOsPrintf ("}\n");
}


/*******************************************************************************
 *
 * FUNCTION:    AcpiDmDumpSerialBusVendorData
 *
 * PARAMETERS:  Resource            - Pointer to the resource descriptor
 *
 * RETURN:      None
 *
 * DESCRIPTION: Dump optional serial bus vendor data
 *
 ******************************************************************************/

static void
AcpiDmDumpSerialBusVendorData (
    AML_RESOURCE            *Resource,
    UINT32                  Level)
{
    UINT8                   *VendorData;
    UINT32                  VendorLength;


    /* Get the (optional) vendor data and length */

    switch (Resource->CommonSerialBus.Type)
    {
    case AML_RESOURCE_I2C_SERIALBUSTYPE:

        VendorLength = Resource->CommonSerialBus.TypeDataLength -
            AML_RESOURCE_I2C_MIN_DATA_LEN;

        VendorData = ACPI_ADD_PTR (UINT8, Resource,
            sizeof (AML_RESOURCE_I2C_SERIALBUS));
        break;

    case AML_RESOURCE_SPI_SERIALBUSTYPE:

        VendorLength = Resource->CommonSerialBus.TypeDataLength -
            AML_RESOURCE_SPI_MIN_DATA_LEN;

        VendorData = ACPI_ADD_PTR (UINT8, Resource,
            sizeof (AML_RESOURCE_SPI_SERIALBUS));
        break;

    case AML_RESOURCE_UART_SERIALBUSTYPE:

        VendorLength = Resource->CommonSerialBus.TypeDataLength -
            AML_RESOURCE_UART_MIN_DATA_LEN;

        VendorData = ACPI_ADD_PTR (UINT8, Resource,
            sizeof (AML_RESOURCE_UART_SERIALBUS));
        break;

    case AML_RESOURCE_CSI2_SERIALBUSTYPE:

        VendorLength = Resource->CommonSerialBus.TypeDataLength -
            AML_RESOURCE_CSI2_MIN_DATA_LEN;

        VendorData = ACPI_ADD_PTR (UINT8, Resource,
            sizeof (AML_RESOURCE_CSI2_SERIALBUS));
        break;

    default:

        return;
    }

    /* Dump the vendor bytes as a RawDataBuffer object */

    AcpiDmDumpRawDataBuffer (VendorData, VendorLength, Level);
}


/*******************************************************************************
 *
 * FUNCTION:    AcpiDmCsi2SerialBusDescriptor
 *
 * PARAMETERS:  Info                - Extra resource info
 *              Resource            - Pointer to the resource descriptor
 *              Length              - Length of the descriptor in bytes
 *              Level               - Current source code indentation level
 *
 * RETURN:      None
 *
 * DESCRIPTION: Decode a CSI2 serial bus descriptor
 *
 ******************************************************************************/

static void
AcpiDmCsi2SerialBusDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level)
{
    UINT32                  ResourceSourceOffset;
    char                    *DeviceName;


    /* SlaveMode, PhyType, LocalPortInstance */

    AcpiDmIndent (Level);
    AcpiOsPrintf ("Csi2Bus (%s,",
        AcpiGbl_SmDecode [ACPI_GET_1BIT_FLAG (Resource->Csi2SerialBus.Flags)]);

    AcpiOsPrintf (" 0x%2.2X, 0x%2.2X,\n",
        Resource->Csi2SerialBus.TypeSpecificFlags & 0x03,
        (Resource->Csi2SerialBus.TypeSpecificFlags & 0xFC) >> 2);

    /* ResourceSource is a required field */

    ResourceSourceOffset = sizeof (AML_RESOURCE_COMMON_SERIALBUS) +
        Resource->CommonSerialBus.TypeDataLength;

    AcpiDmIndent (Level + 1);
    DeviceName = ACPI_ADD_PTR (char, Resource, ResourceSourceOffset);
    AcpiUtPrintString (DeviceName, ACPI_UINT16_MAX);

    /* ResourceSourceIndex, ResourceUsage */

    AcpiOsPrintf (",\n");
    AcpiDmIndent (Level + 1);
    AcpiOsPrintf ("0x%2.2X, ", Resource->Csi2SerialBus.ResSourceIndex);

    AcpiOsPrintf ("%s, ",
        AcpiGbl_ConsumeDecode [ACPI_EXTRACT_1BIT_FLAG (Resource->Csi2SerialBus.Flags, 1)]);

    /* Insert a descriptor name */

    AcpiDmDescriptorName ();

    /* Dump the vendor data */

    AcpiOsPrintf (",\n");
    AcpiDmIndent (Level + 1);
    AcpiDmDumpSerialBusVendorData (Resource, Level);
    AcpiOsPrintf (")\n");

    MpSaveSerialInfo (Info->MappingOp, Resource, DeviceName);
}


/*******************************************************************************
 *
 * FUNCTION:    AcpiDmI2cSerialBusDescriptor
 *
 * PARAMETERS:  Info                - Extra resource info
 *              Resource            - Pointer to the resource descriptor
 *              Length              - Length of the descriptor in bytes
 *              Level               - Current source code indentation level
 *
 * RETURN:      None
 *
 * DESCRIPTION: Decode a I2C serial bus descriptor
 *
 ******************************************************************************/

static void
AcpiDmI2cSerialBusDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level)
{
    UINT32                  ResourceSourceOffset;
    char                    *DeviceName;


    /* SlaveAddress, SlaveMode, ConnectionSpeed, AddressingMode */

    AcpiDmIndent (Level);
    AcpiOsPrintf ("I2cSerialBusV2 (0x%4.4X, %s, 0x%8.8X,\n",
        Resource->I2cSerialBus.SlaveAddress,
        AcpiGbl_SmDecode [ACPI_GET_1BIT_FLAG (Resource->I2cSerialBus.Flags)],
        Resource->I2cSerialBus.ConnectionSpeed);

    AcpiDmIndent (Level + 1);
    AcpiOsPrintf ("%s, ",
        AcpiGbl_AmDecode [ACPI_GET_1BIT_FLAG (Resource->I2cSerialBus.TypeSpecificFlags)]);

    /* ResourceSource is a required field */

    ResourceSourceOffset = sizeof (AML_RESOURCE_COMMON_SERIALBUS) +
        Resource->CommonSerialBus.TypeDataLength;

    DeviceName = ACPI_ADD_PTR (char, Resource, ResourceSourceOffset);
    AcpiUtPrintString (DeviceName, ACPI_UINT16_MAX);

    /* ResourceSourceIndex, ResourceUsage */

    AcpiOsPrintf (",\n");
    AcpiDmIndent (Level + 1);
    AcpiOsPrintf ("0x%2.2X, ", Resource->I2cSerialBus.ResSourceIndex);

    AcpiOsPrintf ("%s, ",
        AcpiGbl_ConsumeDecode [ACPI_EXTRACT_1BIT_FLAG (Resource->I2cSerialBus.Flags, 1)]);

    /* Insert a descriptor name */

    AcpiDmDescriptorName ();

    /* Share */

    AcpiOsPrintf (", %s,\n",
        AcpiGbl_ShrDecode [ACPI_EXTRACT_1BIT_FLAG (Resource->I2cSerialBus.Flags, 2)]);

    /* Dump the vendor data */

    AcpiDmIndent (Level + 1);
    AcpiDmDumpSerialBusVendorData (Resource, Level);
    AcpiOsPrintf (")\n");

    MpSaveSerialInfo (Info->MappingOp, Resource, DeviceName);
}


/*******************************************************************************
 *
 * FUNCTION:    AcpiDmSpiSerialBusDescriptor
 *
 * PARAMETERS:  Info                - Extra resource info
 *              Resource            - Pointer to the resource descriptor
 *              Length              - Length of the descriptor in bytes
 *              Level               - Current source code indentation level
 *
 * RETURN:      None
 *
 * DESCRIPTION: Decode a SPI serial bus descriptor
 *
 ******************************************************************************/

static void
AcpiDmSpiSerialBusDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level)
{
    UINT32                  ResourceSourceOffset;
    char                    *DeviceName;


    /* DeviceSelection, DeviceSelectionPolarity, WireMode, DataBitLength */

    AcpiDmIndent (Level);
    AcpiOsPrintf ("SpiSerialBusV2 (0x%4.4X, %s, %s, 0x%2.2X,\n",
        Resource->SpiSerialBus.DeviceSelection,
        AcpiGbl_DpDecode [ACPI_EXTRACT_1BIT_FLAG (Resource->SpiSerialBus.TypeSpecificFlags, 1)],
        AcpiGbl_WmDecode [ACPI_GET_1BIT_FLAG (Resource->SpiSerialBus.TypeSpecificFlags)],
        Resource->SpiSerialBus.DataBitLength);

    /* SlaveMode, ConnectionSpeed, ClockPolarity, ClockPhase */

    AcpiDmIndent (Level + 1);
    AcpiOsPrintf ("%s, 0x%8.8X, %s,\n",
        AcpiGbl_SmDecode [ACPI_GET_1BIT_FLAG (Resource->SpiSerialBus.Flags)],
        Resource->SpiSerialBus.ConnectionSpeed,
        AcpiGbl_CpoDecode [ACPI_GET_1BIT_FLAG (Resource->SpiSerialBus.ClockPolarity)]);

    AcpiDmIndent (Level + 1);
    AcpiOsPrintf ("%s, ",
        AcpiGbl_CphDecode [ACPI_GET_1BIT_FLAG (Resource->SpiSerialBus.ClockPhase)]);

    /* ResourceSource is a required field */

    ResourceSourceOffset = sizeof (AML_RESOURCE_COMMON_SERIALBUS) +
        Resource->CommonSerialBus.TypeDataLength;

    DeviceName = ACPI_ADD_PTR (char, Resource, ResourceSourceOffset);
    AcpiUtPrintString (DeviceName, ACPI_UINT16_MAX);

    /* ResourceSourceIndex, ResourceUsage */

    AcpiOsPrintf (",\n");
    AcpiDmIndent (Level + 1);
    AcpiOsPrintf ("0x%2.2X, ", Resource->SpiSerialBus.ResSourceIndex);

    AcpiOsPrintf ("%s, ",
        AcpiGbl_ConsumeDecode [ACPI_EXTRACT_1BIT_FLAG (Resource->SpiSerialBus.Flags, 1)]);

    /* Insert a descriptor name */

    AcpiDmDescriptorName ();

    /* Share */

    AcpiOsPrintf (", %s,\n",
        AcpiGbl_ShrDecode [ACPI_EXTRACT_1BIT_FLAG (Resource->SpiSerialBus.Flags, 2)]);

    /* Dump the vendor data */

    AcpiDmIndent (Level + 1);
    AcpiDmDumpSerialBusVendorData (Resource, Level);
    AcpiOsPrintf (")\n");

    MpSaveSerialInfo (Info->MappingOp, Resource, DeviceName);
}


/*******************************************************************************
 *
 * FUNCTION:    AcpiDmUartSerialBusDescriptor
 *
 * PARAMETERS:  Info                - Extra resource info
 *              Resource            - Pointer to the resource descriptor
 *              Length              - Length of the descriptor in bytes
 *              Level               - Current source code indentation level
 *
 * RETURN:      None
 *
 * DESCRIPTION: Decode a UART serial bus descriptor
 *
 ******************************************************************************/

static void
AcpiDmUartSerialBusDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level)
{
    UINT32                  ResourceSourceOffset;
    char                    *DeviceName;


    /* ConnectionSpeed, BitsPerByte, StopBits */

    AcpiDmIndent (Level);
    AcpiOsPrintf ("UartSerialBusV2 (0x%8.8X, %s, %s,\n",
        Resource->UartSerialBus.DefaultBaudRate,
        AcpiGbl_BpbDecode [ACPI_EXTRACT_3BIT_FLAG (Resource->UartSerialBus.TypeSpecificFlags, 4)],
        AcpiGbl_SbDecode [ACPI_EXTRACT_2BIT_FLAG (Resource->UartSerialBus.TypeSpecificFlags, 2)]);

    /* LinesInUse, IsBigEndian, Parity, FlowControl */

    AcpiDmIndent (Level + 1);
    AcpiOsPrintf ("0x%2.2X, %s, %s, %s,\n",
        Resource->UartSerialBus.LinesEnabled,
        AcpiGbl_EdDecode [ACPI_EXTRACT_1BIT_FLAG (Resource->UartSerialBus.TypeSpecificFlags, 7)],
        AcpiGbl_PtDecode [ACPI_GET_3BIT_FLAG (Resource->UartSerialBus.Parity)],
        AcpiGbl_FcDecode [ACPI_GET_2BIT_FLAG (Resource->UartSerialBus.TypeSpecificFlags)]);

    /* ReceiveBufferSize, TransmitBufferSize */

    AcpiDmIndent (Level + 1);
    AcpiOsPrintf ("0x%4.4X, 0x%4.4X, ",
        Resource->UartSerialBus.RxFifoSize,
        Resource->UartSerialBus.TxFifoSize);

    /* ResourceSource is a required field */

    ResourceSourceOffset = sizeof (AML_RESOURCE_COMMON_SERIALBUS) +
        Resource->CommonSerialBus.TypeDataLength;

    DeviceName = ACPI_ADD_PTR (char, Resource, ResourceSourceOffset);
    AcpiUtPrintString (DeviceName, ACPI_UINT16_MAX);

    /* ResourceSourceIndex, ResourceUsage */

    AcpiOsPrintf (",\n");
    AcpiDmIndent (Level + 1);
    AcpiOsPrintf ("0x%2.2X, ", Resource->UartSerialBus.ResSourceIndex);

    AcpiOsPrintf ("%s, ",
        AcpiGbl_ConsumeDecode [ACPI_EXTRACT_1BIT_FLAG (Resource->UartSerialBus.Flags, 1)]);

    /* Insert a descriptor name */

    AcpiDmDescriptorName ();

    /* Share */

    AcpiOsPrintf (", %s,\n",
        AcpiGbl_ShrDecode [ACPI_EXTRACT_1BIT_FLAG (Resource->UartSerialBus.Flags, 2)]);

    /* Dump the vendor data */

    AcpiDmIndent (Level + 1);
    AcpiDmDumpSerialBusVendorData (Resource, Level);
    AcpiOsPrintf (")\n");

    MpSaveSerialInfo (Info->MappingOp, Resource, DeviceName);
}


/*******************************************************************************
 *
 * FUNCTION:    AcpiDmSerialBusDescriptor
 *
 * PARAMETERS:  Info                - Extra resource info
 *              Resource            - Pointer to the resource descriptor
 *              Length              - Length of the descriptor in bytes
 *              Level               - Current source code indentation level
 *
 * RETURN:      None
 *
 * DESCRIPTION: Decode a I2C/SPI/UART/CSI2 serial bus descriptor
 *
 ******************************************************************************/

void
AcpiDmSerialBusDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level)
{

    SerialBusResourceDispatch [Resource->CommonSerialBus.Type] (
        Info, Resource, Length, Level);
}

/*******************************************************************************
 *
 * FUNCTION:    AcpiDmPinConfig
 *
 * PARAMETERS:  PinConfigType       - Pin configuration type
 *              PinConfigValue      - Pin configuration value
 *
 * RETURN:      None
 *
 * DESCRIPTION: Pretty prints PinConfig type and value.
 *
 ******************************************************************************/

static void
AcpiDmPinConfig(
    UINT8                   PinConfigType,
    UINT32                  PinConfigValue)
{
    if (PinConfigType <= 13)
    {
        AcpiOsPrintf ("0x%2.2X /* %s */, ", PinConfigType,
            AcpiGbl_PtypDecode[PinConfigType]);
    }
    else
    {
        AcpiOsPrintf ("0x%2.2X, /* Vendor Defined */ ", PinConfigType);
    }

    /* PinConfigValue */

    AcpiOsPrintf ("0x%4.4X,\n", PinConfigValue);
}

/*******************************************************************************
 *
 * FUNCTION:    AcpiDmPinConfigDescriptor
 *
 * PARAMETERS:  Info                - Extra resource info
 *              Resource            - Pointer to the resource descriptor
 *              Length              - Length of the descriptor in bytes
 *              Level               - Current source code indentation level
 *
 * RETURN:      None
 *
 * DESCRIPTION: Decode a PinConfig descriptor
 *
 ******************************************************************************/

void
AcpiDmPinConfigDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level)
{
    UINT16                  *PinList;
    UINT8                   *VendorData;
    char                    *DeviceName = NULL;
    UINT32                  PinCount;
    UINT32                  i;

    AcpiDmIndent (Level);
    AcpiOsPrintf ("PinConfig (%s, ",
        AcpiGbl_ShrDecode [ACPI_GET_1BIT_FLAG (Resource->PinConfig.Flags)]);

    AcpiDmPinConfig (Resource->PinConfig.PinConfigType,
        Resource->PinConfig.PinConfigValue);

    AcpiDmIndent (Level + 1);

    if (Resource->PinConfig.ResSourceOffset)
    {
        DeviceName = ACPI_ADD_PTR (char,
            Resource, Resource->PinConfig.ResSourceOffset),
        AcpiUtPrintString (DeviceName, ACPI_UINT16_MAX);
    }

    AcpiOsPrintf (", ");
    AcpiOsPrintf ("0x%2.2X, ", Resource->PinConfig.ResSourceIndex);

    AcpiOsPrintf ("%s, ",
        AcpiGbl_ConsumeDecode [ACPI_EXTRACT_1BIT_FLAG (Resource->PinConfig.Flags, 1)]);

    /* Insert a descriptor name */

    AcpiDmDescriptorName ();

    AcpiOsPrintf (",");

    /* Dump the vendor data */

    if (Resource->PinConfig.VendorLength)
    {
        AcpiOsPrintf ("\n");
        AcpiDmIndent (Level + 1);
        VendorData = ACPI_ADD_PTR (UINT8, Resource,
            Resource->PinConfig.VendorOffset);

        AcpiDmDumpRawDataBuffer (VendorData,
            Resource->PinConfig.VendorLength, Level);
    }

    AcpiOsPrintf (")\n");

    AcpiDmIndent (Level + 1);

    /* Dump the interrupt list */

    AcpiOsPrintf ("{   // Pin list\n");

    PinCount = ((UINT32) (Resource->PinConfig.ResSourceOffset -
        Resource->PinConfig.PinTableOffset)) /
        sizeof (UINT16);

    PinList = (UINT16 *) ACPI_ADD_PTR (char, Resource,
        Resource->PinConfig.PinTableOffset);

    for (i = 0; i < PinCount; i++)
    {
        AcpiDmIndent (Level + 2);
        AcpiOsPrintf ("0x%4.4X%s\n", PinList[i],
            ((i + 1) < PinCount) ? "," : "");
    }

    AcpiDmIndent (Level + 1);
    AcpiOsPrintf ("}\n");
}

/*******************************************************************************
 *
 * FUNCTION:    AcpiDmPinGroupDescriptor
 *
 * PARAMETERS:  Info                - Extra resource info
 *              Resource            - Pointer to the resource descriptor
 *              Length              - Length of the descriptor in bytes
 *              Level               - Current source code indentation level
 *
 * RETURN:      None
 *
 * DESCRIPTION: Decode a PinGroup descriptor
 *
 ******************************************************************************/

void
AcpiDmPinGroupDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level)
{
    char                    *Label;
    UINT16                  *PinList;
    UINT8                   *VendorData;
    UINT32                  PinCount;
    UINT32                  i;

    AcpiDmIndent (Level);
    /* Always producer */
    AcpiOsPrintf ("PinGroup (");

    Label = ACPI_ADD_PTR (char,
        Resource, Resource->PinGroup.LabelOffset),
    AcpiUtPrintString (Label, ACPI_UINT16_MAX);

    AcpiOsPrintf (", ");

    AcpiOsPrintf ("%s, ",
        AcpiGbl_ConsumeDecode [ACPI_GET_1BIT_FLAG (Resource->PinGroup.Flags)]);

    /* Insert a descriptor name */

    AcpiDmDescriptorName ();

    AcpiOsPrintf (",");

    /* Dump the vendor data */

    if (Resource->PinGroup.VendorLength)
    {
        AcpiOsPrintf ("\n");
        AcpiDmIndent (Level + 1);
        VendorData = ACPI_ADD_PTR (UINT8, Resource,
            Resource->PinGroup.VendorOffset);

        AcpiDmDumpRawDataBuffer (VendorData,
            Resource->PinGroup.VendorLength, Level);
    }

    AcpiOsPrintf (")\n");

    AcpiDmIndent (Level + 1);

    /* Dump the interrupt list */

    AcpiOsPrintf ("{   // Pin list\n");

    PinCount = (Resource->PinGroup.LabelOffset -
        Resource->PinGroup.PinTableOffset) / sizeof (UINT16);

    PinList = (UINT16 *) ACPI_ADD_PTR (char, Resource,
        Resource->PinGroup.PinTableOffset);

    for (i = 0; i < PinCount; i++)
    {
        AcpiDmIndent (Level + 2);
        AcpiOsPrintf ("0x%4.4X%s\n", PinList[i],
            ((i + 1) < PinCount) ? "," : "");
    }

    AcpiDmIndent (Level + 1);
    AcpiOsPrintf ("}\n");
}

/*******************************************************************************
 *
 * FUNCTION:    AcpiDmPinGroupFunctionDescriptor
 *
 * PARAMETERS:  Info                - Extra resource info
 *              Resource            - Pointer to the resource descriptor
 *              Length              - Length of the descriptor in bytes
 *              Level               - Current source code indentation level
 *
 * RETURN:      None
 *
 * DESCRIPTION: Decode a PinGroupFunction descriptor
 *
 ******************************************************************************/

void
AcpiDmPinGroupFunctionDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level)
{
    UINT8                   *VendorData;
    char                    *DeviceName = NULL;
    char                    *Label = NULL;

    AcpiDmIndent (Level);
    AcpiOsPrintf ("PinGroupFunction (%s, ",
        AcpiGbl_ShrDecode [ACPI_GET_1BIT_FLAG (Resource->PinGroupFunction.Flags)]);

    /* FunctionNumber */

    AcpiOsPrintf ("0x%4.4X, ", Resource->PinGroupFunction.FunctionNumber);

    DeviceName = ACPI_ADD_PTR (char,
        Resource, Resource->PinGroupFunction.ResSourceOffset),
    AcpiUtPrintString (DeviceName, ACPI_UINT16_MAX);

    AcpiOsPrintf (", ");
    AcpiOsPrintf ("0x%2.2X,\n", Resource->PinGroupFunction.ResSourceIndex);

    AcpiDmIndent (Level + 1);

    Label = ACPI_ADD_PTR (char, Resource,
        Resource->PinGroupFunction.ResSourceLabelOffset);
    AcpiUtPrintString (Label, ACPI_UINT16_MAX);

    AcpiOsPrintf (", ");

    AcpiOsPrintf ("%s, ",
        AcpiGbl_ConsumeDecode [ACPI_EXTRACT_1BIT_FLAG (Resource->PinGroupFunction.Flags, 1)]);

    /* Insert a descriptor name */

    AcpiDmDescriptorName ();

    AcpiOsPrintf (",");

    /* Dump the vendor data */

    if (Resource->PinGroupFunction.VendorLength)
    {
        AcpiOsPrintf ("\n");
        AcpiDmIndent (Level + 1);
        VendorData = ACPI_ADD_PTR (UINT8, Resource,
            Resource->PinGroupFunction.VendorOffset);

        AcpiDmDumpRawDataBuffer (VendorData,
            Resource->PinGroupFunction.VendorLength, Level);
    }

    AcpiOsPrintf (")\n");
}

/*******************************************************************************
 *
 * FUNCTION:    AcpiDmPinGroupConfigDescriptor
 *
 * PARAMETERS:  Info                - Extra resource info
 *              Resource            - Pointer to the resource descriptor
 *              Length              - Length of the descriptor in bytes
 *              Level               - Current source code indentation level
 *
 * RETURN:      None
 *
 * DESCRIPTION: Decode a PinGroupConfig descriptor
 *
 ******************************************************************************/

void
AcpiDmPinGroupConfigDescriptor (
    ACPI_OP_WALK_INFO       *Info,
    AML_RESOURCE            *Resource,
    UINT32                  Length,
    UINT32                  Level)
{
    UINT8                   *VendorData;
    char                    *DeviceName = NULL;
    char                    *Label = NULL;

    AcpiDmIndent (Level);
    AcpiOsPrintf ("PinGroupConfig (%s, ",
        AcpiGbl_ShrDecode [ACPI_GET_1BIT_FLAG (Resource->PinGroupConfig.Flags)]);

    AcpiDmPinConfig(Resource->PinGroupConfig.PinConfigType,
        Resource->PinGroupConfig.PinConfigValue);

    AcpiDmIndent (Level + 1);

    DeviceName = ACPI_ADD_PTR (char,
        Resource, Resource->PinGroupConfig.ResSourceOffset),
    AcpiUtPrintString (DeviceName, ACPI_UINT16_MAX);

    AcpiOsPrintf (", ");
    AcpiOsPrintf ("0x%2.2X, ", Resource->PinGroupConfig.ResSourceIndex);

    Label = ACPI_ADD_PTR (char, Resource,
        Resource->PinGroupConfig.ResSourceLabelOffset);
    AcpiUtPrintString (Label, ACPI_UINT16_MAX);

    AcpiOsPrintf (", ");

    AcpiOsPrintf ("%s, ",
        AcpiGbl_ConsumeDecode [ACPI_EXTRACT_1BIT_FLAG (Resource->PinGroupConfig.Flags, 1)]);

    /* Insert a descriptor name */

    AcpiDmDescriptorName ();

    AcpiOsPrintf (",");

    /* Dump the vendor data */

    if (Resource->PinGroupConfig.VendorLength)
    {
        AcpiOsPrintf ("\n");
        AcpiDmIndent (Level + 1);
        VendorData = ACPI_ADD_PTR (UINT8, Resource,
            Resource->PinGroupConfig.VendorOffset);

        AcpiDmDumpRawDataBuffer (VendorData,
            Resource->PinGroupConfig.VendorLength, Level);
    }

    AcpiOsPrintf (")\n");
}
