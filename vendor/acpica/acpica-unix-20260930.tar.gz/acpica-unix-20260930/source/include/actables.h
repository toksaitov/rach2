/******************************************************************************
 *
 * Name: actables.h - ACPI table management
 *
 *****************************************************************************/

/******************************************************************************
 *
 * Copyright (c) 1999 - 2026, Intel Corp.
 * SPDX-License-Identifier: BSD-3-Clause OR GPL-2.0-only
 *
 *****************************************************************************/

#ifndef __ACTABLES_H__
#define __ACTABLES_H__


ACPI_STATUS
AcpiAllocateRootTable (
    UINT32                  InitialTableCount);

/*
 * tbxfroot - Root pointer utilities
 */
UINT32
AcpiTbGetRsdpLength (
    ACPI_TABLE_RSDP         *Rsdp);

ACPI_STATUS
AcpiTbValidateRsdp (
    ACPI_TABLE_RSDP         *Rsdp);

UINT8 *
AcpiTbScanMemoryForRsdp (
    UINT8                   *StartAddress,
    UINT32                  Length);


/*
 * tbdata - table data structure management
 */
ACPI_STATUS
AcpiTbGetNextTableDescriptor (
    UINT32                  *TableIndex,
    ACPI_TABLE_DESC         **TableDesc);

void
AcpiTbInitTableDescriptor (
    ACPI_TABLE_DESC         *TableDesc,
    ACPI_PHYSICAL_ADDRESS   Address,
    UINT8                   Flags,
    ACPI_TABLE_HEADER       *Table);

ACPI_STATUS
AcpiTbAcquireTempTable (
    ACPI_TABLE_DESC         *TableDesc,
    ACPI_PHYSICAL_ADDRESS   Address,
    UINT8                   Flags,
    ACPI_TABLE_HEADER       *Table);

void
AcpiTbReleaseTempTable (
    ACPI_TABLE_DESC         *TableDesc);

ACPI_STATUS
AcpiTbValidateTempTable (
    ACPI_TABLE_DESC         *TableDesc);

ACPI_STATUS
AcpiTbVerifyTempTable (
    ACPI_TABLE_DESC         *TableDesc,
    char                    *Signature,
    UINT32                  *TableIndex);

BOOLEAN
AcpiTbIsTableLoaded (
    UINT32                  TableIndex);

void
AcpiTbSetTableLoadedFlag (
    UINT32                  TableIndex,
    BOOLEAN                 IsLoaded);


/*
 * tbfadt - FADT parse/convert/validate
 */
void
AcpiTbParseFadt (
    void);

void
AcpiTbCreateLocalFadt (
    ACPI_TABLE_HEADER       *Table,
    UINT32                  Length);


/*
 * tbfind - find ACPI table
 */
ACPI_STATUS
AcpiTbFindTable (
    char                    *Signature,
    char                    *OemId,
    char                    *OemTableId,
    UINT32                  *TableIndex);


/*
 * tbinstal - Table removal and deletion
 */
ACPI_STATUS
AcpiTbResizeRootTableList (
    void);

ACPI_STATUS
AcpiTbValidateTable (
    ACPI_TABLE_DESC         *TableDesc);

void
AcpiTbInvalidateTable (
    ACPI_TABLE_DESC         *TableDesc);

void
AcpiTbOverrideTable (
    ACPI_TABLE_DESC         *OldTableDesc);

ACPI_STATUS
AcpiTbAcquireTable (
    ACPI_TABLE_DESC         *TableDesc,
    ACPI_TABLE_HEADER       **TablePtr,
    UINT32                  *TableLength,
    UINT8                   *TableFlags);

void
AcpiTbReleaseTable (
    ACPI_TABLE_HEADER       *Table,
    UINT32                  TableLength,
    UINT8                   TableFlags);

ACPI_STATUS
AcpiTbInstallStandardTable (
    ACPI_PHYSICAL_ADDRESS   Address,
    UINT8                   Flags,
    ACPI_TABLE_HEADER       *Table,
    BOOLEAN                 Reload,
    BOOLEAN                 Override,
    UINT32                  *TableIndex);

void
AcpiTbUninstallTable (
    ACPI_TABLE_DESC        *TableDesc);

ACPI_STATUS
AcpiTbLoadTable (
    UINT32                  TableIndex,
    ACPI_NAMESPACE_NODE     *ParentNode);

ACPI_STATUS
AcpiTbInstallAndLoadTable (
    ACPI_PHYSICAL_ADDRESS   Address,
    UINT8                   Flags,
    ACPI_TABLE_HEADER       *Table,
    BOOLEAN                 Override,
    UINT32                  *TableIndex);

ACPI_STATUS
AcpiTbUnloadTable (
    UINT32                  TableIndex);

void
AcpiTbNotifyTable (
    UINT32                          Event,
    void                            *Table);

void
AcpiTbTerminate (
    void);

ACPI_STATUS
AcpiTbDeleteNamespaceByOwner (
    UINT32                  TableIndex);

ACPI_STATUS
AcpiTbAllocateOwnerId (
    UINT32                  TableIndex);

ACPI_STATUS
AcpiTbReleaseOwnerId (
    UINT32                  TableIndex);

ACPI_STATUS
AcpiTbGetOwnerId (
    UINT32                  TableIndex,
    ACPI_OWNER_ID           *OwnerId);


/*
 * tbutils - table manager utilities
 */
ACPI_STATUS
AcpiTbInitializeFacs (
    void);

void
AcpiTbPrintTableHeader(
    ACPI_PHYSICAL_ADDRESS   Address,
    ACPI_TABLE_HEADER       *Header);

void
AcpiTbCheckDsdtHeader (
    void);

ACPI_TABLE_HEADER *
AcpiTbCopyDsdt (
    UINT32                  TableIndex);

void
AcpiTbInstallTableWithOverride (
    ACPI_TABLE_DESC         *NewTableDesc,
    BOOLEAN                 Override,
    UINT32                  *TableIndex);

ACPI_STATUS
AcpiTbParseRootTable (
    ACPI_PHYSICAL_ADDRESS   RsdpAddress);

ACPI_STATUS
AcpiTbGetTable (
    ACPI_TABLE_DESC        *TableDesc,
    ACPI_TABLE_HEADER      **OutTable);

void
AcpiTbPutTable (
    ACPI_TABLE_DESC        *TableDesc);


/*
 * tbxfload
 */
ACPI_STATUS
AcpiTbLoadNamespace (
    void);

#endif /* __ACTABLES_H__ */
