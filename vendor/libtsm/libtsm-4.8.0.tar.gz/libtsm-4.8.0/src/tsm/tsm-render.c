/*
 * libtsm - Rendering
 *
 * Copyright (c) 2011-2013 David Herrmann <dh.herrmann@gmail.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files
 * (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * Rendering
 * TSM does not depend on any graphics system or rendering libraries. Instead,
 * it provides iterators and ageing support so you can implement renderers
 * yourself.
 */

#include <inttypes.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "libtsm.h"
#include "libtsm-int.h"
#include "shl-llog.h"
#include "shl_dlist.h"

#define LLOG_SUBSYSTEM "tsm-render"

SHL_EXPORT
tsm_age_t tsm_screen_draw(struct tsm_screen *con, tsm_screen_draw_cb draw_cb,
			  void *data)
{
	unsigned int cur_x, cur_y;
	unsigned int i, j, k;
	struct line *line, *next_line = NULL;
	struct cell *cell, empty;
	struct tsm_screen_attr attr;
	int ret, warned = 0;
	const uint32_t *ch;
	uint64_t id;
	size_t len;
	bool in_sel = false, sel_start = false, sel_end = false;
	bool was_sel = false;
	tsm_age_t age;

	if (!con || !draw_cb)
		return 0;

	screen_cell_init(con, &empty);

	cur_x = con->cursor_x;
	if (con->cursor_x >= con->size_x)
		cur_x = con->size_x - 1;
	cur_y = con->cursor_y;
	if (con->cursor_y >= con->size_y)
		cur_y = con->size_y - 1;

	/* push each character into rendering pipeline */
	k = 0;
	next_line = con->sb.pos;

	if (con->sel_active) {
		if (!con->sel_start.line)
			in_sel = !in_sel;
		if (!con->sel_end.line)
			in_sel = !in_sel;

		if (is_in_scrollback(&con->sel_start) &&
		    (!con->sb.pos || con->sel_start.line->sb_id < con->sb.pos->sb_id))
			in_sel = !in_sel;
		if (is_in_scrollback(&con->sel_end) &&
		    (!con->sb.pos || con->sel_end.line->sb_id < con->sb.pos->sb_id))
			in_sel = !in_sel;
	}

	for (i = 0; i < con->size_y; ++i) {
		if (next_line) {
			line = next_line;
			next_line = shl_dlist_next(next_line, &con->sb.list, list);
		} else {
			line = con->lines[k];
			k++;
		}

		if (con->sel_active) {
			if (con->sel_start.line == line)
				sel_start = true;
			else
				sel_start = false;
			if (con->sel_end.line == line)
				sel_end = true;
			else
				sel_end = false;
			was_sel = false;
		}

		for (j = 0; j < con->size_x; ++j) {
			if (j < line->size)
				cell = &line->cells[j];
			else
				cell = &empty;

			memcpy(&attr, &cell->attr, sizeof(attr));

			if (con->sel_active) {
				if (sel_start &&
				    j == con->sel_start.x) {
					was_sel = in_sel;
					in_sel = !in_sel;
				}
				if (sel_end &&
				    j == con->sel_end.x) {
					was_sel = in_sel;
					in_sel = !in_sel;
				}
			}

			if (k == cur_y + 1 && j == cur_x &&
			    !(con->flags & TSM_SCREEN_HIDE_CURSOR))
				attr.inverse = !attr.inverse;

			/* TODO: do some more sophisticated inverse here. When
			 * INVERSE mode is set, we should instead just select
			 * inverse colors instead of switching background and
			 * foreground */
			if (con->flags & TSM_SCREEN_INVERSE)
				attr.inverse = !attr.inverse;

			if (in_sel || was_sel) {
				was_sel = false;
				attr.inverse = !attr.inverse;
			}

			if (con->age_reset) {
				age = 0;
			} else {
				age = cell->age;
				if (line->age > age)
					age = line->age;
				if (con->age > age)
					age = con->age;
			}

			/* Encode attributes into the id to avoid caching problems */
			id = cell->ch;
			if (attr.bold)
				id |= 1ULL << TSM_UCS4_MAX_BITS;
			if (attr.italic)
				id |= 1ULL << (TSM_UCS4_MAX_BITS + 1);
			if (attr.underline)
				id |= 1ULL << (TSM_UCS4_MAX_BITS + 2);
			if (attr.inverse)
				id |= 1ULL << (TSM_UCS4_MAX_BITS + 3);
			if (attr.blink)
				id |= 1ULL << (TSM_UCS4_MAX_BITS + 4);

			ch = tsm_symbol_get(con->sym_table, &cell->ch, &len);
			if (cell->ch == 0 || (cell->ch == ' ' && !attr.underline))
				len = 0;
			ret = draw_cb(con, id, ch, len, cell->width,
				      j, i, &attr, age, data);
			if (ret && warned++ < 3) {
				llog_debug(con,
					   "cannot draw glyph at %ux%u via text-renderer",
					   j, i);
				if (warned == 3)
					llog_debug(con,
						   "suppressing further warnings during this rendering round");
			}
		}
	}

	if (con->age_reset) {
		con->age_reset = 0;
		return 0;
	} else {
		return con->age_cnt;
	}
}

static void color_dim(struct tsm_screen_color  *out, const struct tsm_screen_color *fg, const struct tsm_screen_color *bg)
{
	out->r = bg->r / 2 + fg->r / 2;
	out->g = bg->g / 2 + fg->g / 2;
	out->b = bg->b / 2 + fg->b / 2;
}

/*
 * tsm_screen_draw2 returns a pointer to a table of tsm_screen_cell, one for each cell on the screen.
 * It uses a bit more memory, but should be much faster, as each cell is only 12 bytes.
 * The caller can read the table, until the next call to tsm_screen_draw2, or until con is destroyed.
 */
SHL_EXPORT
const struct tsm_screen_cell *tsm_screen_draw2(struct tsm_screen *con)
{
	unsigned int i, j, k;
	struct line *line, *next_line = NULL;
	struct cell *cell, empty;
	struct tsm_screen_cell *out;
	bool in_sel = false, sel_start = false, sel_end = false;
	bool inverse = false;

	if (!con)
		return NULL;

	if (con->cells_count < con->size_x * con->size_y) {
		free(con->cells);
		con->cells_count = 0;
		con->cells = malloc(con->size_x * con->size_y * sizeof(struct tsm_screen_cell));
		if (!con->cells)
			return NULL;
		con->cells_count = con->size_x * con->size_y;
		memset(con->cells, 0, con->cells_count * sizeof(struct tsm_screen_cell));
	}

	screen_cell_init(con, &empty);

	/* push each character into rendering pipeline */
	k = 0;
	next_line = con->sb.pos;

	if (con->sel_active) {
		if (!con->sel_start.line && con->sel_end.line)
			in_sel = true;

		if (is_in_scrollback(&con->sel_start)
			&& (!con->sb.pos || con->sel_start.line->sb_id < con->sb.pos->sb_id))
			in_sel = !in_sel;
		if (is_in_scrollback(&con->sel_end)
			&& (!con->sb.pos || con->sel_end.line->sb_id < con->sb.pos->sb_id))
			in_sel = !in_sel;
	}

	for (i = 0; i < con->size_y; ++i) {
		if (next_line) {
			line = next_line;
			next_line = shl_dlist_next(next_line, &con->sb.list, list);
		} else {
			line = con->lines[k];
			k++;
		}

		if (con->sel_active) {
			sel_start = (con->sel_start.line == line);
			sel_end = (con->sel_end.line == line);
		}

		for (j = 0; j < con->size_x; ++j) {
			out = &con->cells[i * con->size_x + j];
			/* don't handle multiple codepoints yet */
			if (j < line->size && line->cells[j].ch <= TSM_UCS4_MAX)
				cell = &line->cells[j];
			else
				cell = &empty;
			out->ch = cell->ch ? cell->ch : ' ';
			out->attr2.bold = cell->attr.bold;
			out->attr2.italic = cell->attr.italic;
			out->attr2.underline = cell->attr.underline;
			out->attr2.blink = cell->attr.blink;

			if (sel_start && j == con->sel_start.x)
				in_sel = !in_sel;

			/* Inverse logic, cell attribute, selection, and whole screen inverse */
			inverse = cell->attr.inverse ^ in_sel ^ (con->flags & TSM_SCREEN_INVERSE);

			if (inverse) {
				out->fg.r = cell->attr.br;
				out->fg.g = cell->attr.bg;
				out->fg.b = cell->attr.bb;
				out->bg.r = cell->attr.fr;
				out->bg.g = cell->attr.fg;
				out->bg.b = cell->attr.fb;
			} else {
				out->fg.r = cell->attr.fr;
				out->fg.g = cell->attr.fg;
				out->fg.b = cell->attr.fb;
				out->bg.r = cell->attr.br;
				out->bg.g = cell->attr.bg;
				out->bg.b = cell->attr.bb;
			}
			if (cell->attr.dim)
				color_dim(&out->fg, &out->fg, &out->bg);

			if (sel_end && j == con->sel_end.x)
				in_sel = !in_sel;
		}
	}
	return con->cells;
}
